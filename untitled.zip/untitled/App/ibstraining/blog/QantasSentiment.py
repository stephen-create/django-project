import tweepy
from textblob import TextBlob
import numpy as np
import psycopg2


consumer_key = 'So51E8JLImVGOMMQCEYx0HvTs'
consumer_secret = 'A69s2XOCdGkFVE6iXsWNAC9Jqcy85XZ6c21RczQz9HmsNwXAiI'
access_token = '3140214565-GnIJ3glwYahtcTMuW8WQz1xsPC7RZA4yweAcyk1'
access_token_secret = 'YBvo7mbesKwalan8EqsoV1hMyHplnOyvu5DwruB8YZTHl'
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth)
public_tweets = api.search('Qantas')

one = []
two = []

l = len(public_tweets)
i = 0

while i < l:
    # print(tweet.text)
    analysis = TextBlob(public_tweets[i].text)
    one.append(analysis.sentiment.polarity)
    two.append(analysis.sentiment.subjectivity)
    i = i + 1

conn = psycopg2.connect(
    database="postgres",
    user="postgres",
    password="stebk1797",
    host="localhost",
    port="5432",
)

cur = conn.cursor()
cur.execute("DELETE FROM public.qantas_sentiment")
insrt_query = """INSERT INTO public.qantas_sentiment(id, polarity, subjectivity)values(%s,%s,%s)"""

i = 0
for i in range(l):
    recrd_to_insrt = (i+1, one[i], two[i])
    cur.execute(insrt_query, recrd_to_insrt)

conn.commit()

cur.execute(r"COPY public.qantas_sentiment TO 'C:\Users\steph\PycharmProjects\untitled\App\ibstraining\blog\QantasSentimentAnalysis.csv' DELIMITER ',' CSV HEADER")


conn.close()



import psycopg2

conn = psycopg2.connect(
    database="postgres",
    user="postgres",
    password="stebk1797",
    host="localhost",
    port="5432",
)
cur = conn.cursor()
cur.execute("SELECT notification FROM public.ana_notifications")
noti = cur.fetchall()
cur1 = conn.cursor()
cur1.execute("SELECT link FROM public.ana_notifications")
li = cur1.fetchall()
l = len(noti)
# print(l)
i = 1
st = ''
bad_chars = [')', ',', '(',"'"]

while i < l:
    a1 = str(li[i])
    for y in bad_chars:
        a1 = a1.replace(y, '')
    a2 = str(noti[i])
    for y in bad_chars:
        a2 = a2.replace(y, '')
    st = st + ('<li class="list-group-item"> <a href="' + a1 + '">' + a2 + '</a> </li>')
    i = i + 1
str1 = '<ul class="list-group">' + st + '</ul>'
#print(str1)

conn.close()
html_file = open('templates/blog/TableAna.html', 'w')
file = html_file.write(str1)
import psycopg2

from App.ibstraining.blog import scraping
from App.ibstraining.blog.scraping import location
from App.ibstraining.blog.scraping import fare
from App.ibstraining.blog.scraping import date
from App.ibstraining.blog.scraping import result

conn = psycopg2.connect(
    database="postgres",
    user="postgres",
    password="stebk1797",
    host="localhost",
    port="5432",
)
one = []
one = location
two = []
two = fare
three = []
three = date

cur = conn.cursor()
cur.execute("DELETE FROM public.qantas_details")
insrt_query="""INSERT INTO public.qantas_details(destination,fares,end_date)values(%s,%s,%s)"""
i=0

for i in range(3):
    recrd_to_insrt = (one[i], two[i], three[i])
    cur.execute(insrt_query,recrd_to_insrt)



conn.commit()
cur.execute(r"COPY public.qantas_details TO 'C:\Users\steph\PycharmProjects\untitled\App\ibstraining\blog\airtickets.csv' DELIMITER '-' CSV HEADER")

# rows = cur.fetchall()

# for row in rows:
# print("destination :", row[0])
# print("fares :", row[1])
# print("end_date", row[2])
# print("\n")



print("DB queries completed")
conn.close()

from prettytable import PrettyTable

a = open("airtickets.csv", 'r')
a = a.readlines()
l1 = a[0]
#print(a[3])
#print(len(a))
l1 = l1.split('-')
t = PrettyTable([l1[0], l1[1], l1[2]])

for i in range(1, len(a)):
    t.add_row(a[i].split('-'))

code = t.get_html_string()
html_file = open('templates/blog/Table.html', 'w')
file = html_file.write(code)


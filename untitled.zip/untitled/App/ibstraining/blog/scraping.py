import requests
from bs4 import BeautifulSoup

page = requests.get('https://www.qantas.com/us/en/flight-deals.html/lax/au/economy/all/lowest')
soup = BeautifulSoup(page.content, 'html.parser')
flight = soup.find(class_='price-list')
# print(flight)
destinations = flight.findAll(class_='price-list__to')
prices = soup.findAll(class_='pricing__price')
end_dates = soup.findAll(class_='price-list__sale-end-date')
l = len(destinations)
location = [destination.get_text() for destination in destinations]
# print(location)
fare = [price.get_text() for price in prices]
# print(fare)
date = [end_date.get_text() for end_date in end_dates]
# print(date)
# filename = "airtickets.csv"
# f = open(filename, "w")
# headers = "Destination,Fares,End_Date\n"
# l = len(location)
# f.write(headers)
# i = 0
# while i < l:
#   f.write(location[i] + "," + fare[i] + "," + date[i] + "\n")
#   i += 1
# f.close()

i = 0
result = ''
for i in range(l):
    result = result + "Destination: " + location[i] + " " + ", Fare: " + fare[i] + ", " + \
             date[i] + "---\n"

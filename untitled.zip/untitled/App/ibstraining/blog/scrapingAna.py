import requests
from bs4 import BeautifulSoup
from idna import unicode

page = requests.get('https://www.ana.co.jp/en/us/serviceinfo/international/information/charge.html')
soup = BeautifulSoup(page.content, 'html.parser')
fare = soup.find(class_='res-inner-contents')
# print(fare)
destinationsAna = fare.findAll(class_='sp-table-def')
# print(destinationsAna)


table = soup.find('table', class_='sp-table-def')
# print(table)
# print(type(table))
table_string = str(table)
t1=table_string.encode('utf-8').strip()
t2 = str(t1)
html_file = open('templates/blog/Table123.html', 'w')
html_file.write(t2)



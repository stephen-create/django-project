import requests
from bs4 import BeautifulSoup
import psycopg2
from idna import unicode

conn = psycopg2.connect(
    database="postgres",
    user="postgres",
    password="stebk1797",
    host="localhost",
    port="5432",
)
cur = conn.cursor()
page = requests.get('https://www.ana.co.jp/en/us/')
soup = BeautifulSoup(page.content, 'html.parser')
details = soup.find(id='spInfoItem')
# print(details)
line = details.findAll('li')
link = details.findAll('a')
cur.execute("DELETE FROM public.ana_notifications")
insrt_query = """INSERT INTO public.ana_notifications(notification,link)VALUES(%s,%s)"""

for i in range(len(line)):
    data1 = line[i].get_text()
    data2 = link[i]['href']
    first_char = data2[0]
    if first_char == '/':
        data3 = 'https://www.ana.co.jp' + data2
    else:
        data3 = data2
    # print(data1)
    # print(data2)
    recrd_to_insrt = (data1, data3)
    cur.execute(insrt_query, recrd_to_insrt)
conn.commit()
# html_file = open('templates/blog/Table123.html', 'w')
# html_file.write(t2)
print("DB Queries completed")
conn.close()

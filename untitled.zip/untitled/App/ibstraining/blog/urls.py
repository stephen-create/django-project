from django.urls import path
from . import views

urlpatterns =[
    path('',views.home, name='blog-home'),
    path('qantas',views.qantas, name='blog-home-qantas'),
    path('qantas/table1', views.table1, name='blog-home-qantas-table1'),
    path('ana/table2', views.table2, name='blog-home-ana-table2'),
    path('ana/tableAna', views.tableAna, name='blog-home-ana-tableAna'),
    path('ana',views.ana, name='blog-home-ana'),
    path('expedia', views.expedia, name='blog-home-expedia'),
    path('webhook', views.webhook, name='webhook'),
]
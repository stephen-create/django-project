
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
import json
from .scraping import result


# Create your views here.
from django.http import HttpResponse
@login_required(login_url="/accounts/login")
def home(request):
    return render(request, 'blog/home.html')

@login_required(login_url="/accounts/login")
def qantas(request):
    return render(request, 'blog/qantas.html')

@login_required(login_url="/accounts/login")
def ana(request):
    return render(request, 'blog/ana.html')

@login_required(login_url="/accounts/login")
def expedia(request):
    return render(request, 'blog/expedia.html')

@login_required(login_url="/accounts/login")
def table1(request):
    return render(request, 'blog/Table.html')

@login_required(login_url="/accounts/login")
def table2(request):
    return render(request, 'blog/Table123.html')

@login_required(login_url="/accounts/login")
def tableAna(request):
    return render(request, 'blog/TableAna.html')

a=result
@csrf_exempt
def webhook(request):
    # build a request object
    req = json.loads(request.body)
    # get action from json
    action = req.get('queryResult').get('action')
    # return a fulfillment message
    fulfillmentText = {'fulfillmentText': a}
    # return response
    return JsonResponse(fulfillmentText, safe=False)

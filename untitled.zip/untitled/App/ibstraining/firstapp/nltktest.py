from nltk.tokenize import word_tokenize
AI = 'it is a blooming branch which has got a lot of openings in the future'
AI_tokens = word_tokenize(AI)
print(AI_tokens)
